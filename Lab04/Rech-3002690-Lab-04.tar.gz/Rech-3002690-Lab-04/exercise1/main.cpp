/*Lab-04 Exercise-01
  main.cpp
	Emmett Rech*/
#include <iostream>
#include <math.h>

using namespace std;

int main()
{
	//declare variables
	int choice = 0;
	int exit = 0;
	int n = 0;
	char ascii = ' ';

	//Input
	while (exit <= 0)
{
	cout << "1) Select a specific number\n2) Display visible ASCII values (33 to 126)\n3) Exit\nChoice: ";
	cin >> choice;

	if(choice == 1)
	{
		cout << "Enter value: ";
		cin >> n;
		//processing
		ascii = (char)n;
		//output
		cout << n << " = " << ascii << endl;
	}
	else if(choice == 2)
	{
		for (int x = 33; x < 126; x++)
		{
			ascii = (char) x;
			cout << x << " = " << ascii << endl;
		}//end for
	}
	else if(choice == 3)
		exit = 1;
	else
		cout << "Invalid choice, try again." << endl;
}//end while


	return (0);
}//end of main
