/*Lab-04 Exercise-03
  main.cpp
	Emmett Rech*/
#include <iostream>
#include <math.h>

using namespace std;

int main()
{
	//declare variables
	int n = 0;
	int d1 = 1;
	int d2 = 5;
	int d3 = 17;
	int now = 0;

	//Input
	cout << "OUTBREAK!\nWhat day do you want a sick count for?: ";
	cin >> n;

	//processing
	if (n <= 0)
		cout << "Invalid input" << endl;
	else
	{
		for(int x = 0; x < n; x++)
		{
			if(x==0)
				now = d1;
			else if(x==1)
				now = d2;
			else if(x==2)
				now = d3;
			else
			{
				now = d1 + d2 + d3;
				d1 = d2;
				d2 = d3;
				d3 = now;
			}//end if
		}//end for
		//output
		cout << "Total people with flu: " << now << endl;
	}//end if

	return (0);
}//end of main
