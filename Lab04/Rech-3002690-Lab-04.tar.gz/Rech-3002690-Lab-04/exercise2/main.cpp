/*Lab-04 Exercise-02
  main.cpp
	Emmett Rech*/
#include <iostream>
#include <math.h>

using namespace std;

int main()
{
	//declare variables
	int n = 0;
	int last = 0;
	int temp = 0;
	int now = 1;

	//Input
	cout << "How many Fibonacci numbers do you want printed?: ";
	cin >> n;

	//processing/output
	for (int x = 0; x <= n; x++)
	{
		if (x == n)
			cout << last;
		else
			cout << last << ", ";
		temp = now;
		now = last + now;
		last = temp;
	}//end for
	cout << endl;

	return (0);
}//end of main
